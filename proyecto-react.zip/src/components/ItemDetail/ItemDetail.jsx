import { useContext, useState } from "react";
import { CartContext } from "../context/CartContext";
import ItemCount from "../Items/ItemCount";  // Ruta correcta

function ItemDetail({ producto }) {
  const { addToCart } = useContext(CartContext);
  const [added, setAdded] = useState(false);

  const { id, nombre, imagen, precio, rating, reviews } = producto;

  const onAdd = (cantidad) => {
    addToCart(producto, cantidad);
    setAdded(true);
  };

  return (
    <div className="detail-card">
      <img src={imagen} alt={nombre} className="detail-img" />

      <div className="detail-info">
        <h2>{nombre}</h2>
        <p className="detail-price">${precio.toLocaleString()}</p>
        <p>⭐ {rating} ({reviews})</p>

        {/* Mostrar contador si no se agregó */}
        {!added ? (
          <ItemCount stock={10} onAdd={onAdd} />
        ) : (
          <button className="go-cart-btn">
            Ir al carrito
          </button>
        )}
      </div>
    </div>
  );
}

export default ItemDetail;
