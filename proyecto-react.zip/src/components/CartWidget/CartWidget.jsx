import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import { FaShoppingCart } from "react-icons/fa";
import "./CartWidget.css";

function CartWidget() {
  const { cartQuantity } = useContext(CartContext);

  return (
    <div className="cart-widget">
      <FaShoppingCart className="cart-icon" />
      {cartQuantity() > 0 && <span className="cart-count">{cartQuantity()}</span>}
    </div>
  );
}

export default CartWidget;
