import { useParams } from "react-router-dom";
import { productos } from "../../data/products";
import ItemDetail from "../ItemDetail/ItemDetail";
import "./ItemDetailContainer.css";

function ItemDetailContainer() {
  const { id } = useParams(); // <-- AHORA SÍ COINCIDE

  const producto = productos.find((p) => p.id === id);

  if (!producto) {
    return <h2 style={{ color: "white" }}>Producto no encontrado</h2>;
  }

  return (
    <div className="item-detail-container">
      <ItemDetail producto={producto} />
    </div>
  );
}

export default ItemDetailContainer;
