import ItemCard from "./ItemCard";

function ItemList({ productos }) {
  return (
    <>
      {productos.map((prod) => (
        <ItemCard key={prod.id} producto={prod} />
      ))}
    </>
  );
}

export default ItemList;
